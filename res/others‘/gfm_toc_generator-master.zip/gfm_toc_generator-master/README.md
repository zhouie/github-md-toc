# gfm_toc_generator
Automatically generate the table of content for GitHub-Flavored-Markdown files.

## Requirement
- Python 3

## Usage
Use the following command in your terminal to use this tool:
```
python gen_gfm_toc.py <path_to_your_markdown_file>
```

Then the table of content will be printed via standard output.
