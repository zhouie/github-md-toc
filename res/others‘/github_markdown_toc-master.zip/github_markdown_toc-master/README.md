# TOC_For_GitHub
## brief
- Generate a TOC for .md file in GitHub which supports Chinese

## usage
```
./gen_TOC.py target_file(.md) [start line]
``` 
 
then you will see a backed-up file and a new file with TOC

- "start line" is the line you want to insert the TOC, it's optionl and the default is 1.
