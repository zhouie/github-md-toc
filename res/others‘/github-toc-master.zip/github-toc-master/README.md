[github-toc](#github-toc)  
　1. [level 2 1st](#level-2-1st)  
　　1.1 [level 3 1st](#level-3-1st)  
　　　　1.1.1 [level 4 1st](#level-4-1st)  
　　　　　　1.1.1.1 [level 5 1st](#level-5-1st)  
　　　　　　　　1.1.1.1.1 [level 6 1st](#level-6-1st)  
　　　　　　　　1.1.1.1.2 [level 6 2nd](#level-6-2nd)  
　　　　　　　　1.1.1.1.3 [level 6 3rd](#level-6-3rd)  
　　　　　　1.1.1.2 [level 5 2nd](#level-5-2nd)  
　　　　　　　　1.1.1.2.1 [level 6 1st](#level-6-1st-1)  
　　　　　　　　1.1.1.2.2 [level 6 2nd](#level-6-2nd-1)  
　　　　　　1.1.1.3 [level 5 3rd](#level-5-3rd)  
　　　　1.1.2 [level 4 2nd](#level-4-2nd)  
　　　　　　1.1.2.1 [level 5 1st](#level-5-1st-1)  
　　　　　　　　1.1.2.1.1 [level 6 1st](#level-6-1st-2)  
　　1.2 [level 3 2nd](#level-3-2nd)  
　　1.3 [level 3 3rd](#level-3-3rd)  
　　1.4 [level 3 4th](#level-3-4th)  
　2. [level 2 2nd](#level-2-2nd)  
　　2.1 [level 3 1st](#level-3-1st-1)  
　　　　2.1.1 [level 4 1st](#level-4-1st-1)  
　　　　　　2.1.1.1 [level 5 1st](#level-5-1st-2)  
　　　　　　　　2.1.1.1.1 [level 6 1st](#level-6-1st-3)  
　3. [Usage](#usage)  
  
# github-toc
Help to generate the TOC of the README.md of your project
  
## level 2 1st  
### level 3 1st  
#### level 4 1st  
##### level 5 1st  
###### level 6 1st  
###### level 6 2nd
###### level 6 3rd  
##### level 5 2nd
###### level 6 1st  
###### level 6 2nd  
##### level 5 3rd  
#### level 4 2nd  
##### level 5 1st  
###### level 6 1st  
### level 3 2nd  
### level 3 3rd  
### level 3 4th  
## level 2 2nd
### level 3 1st  
#### level 4 1st  
##### level 5 1st  
###### level 6 1st  
## Usage
Copy the ```README.md``` to the folder.  
If README.md.bak already exist before generating the TOC, please delete the old README.md.bak.
Then you can exec ```Python3 genTOC.py``` or ```run.bat``` in Windows OS.
